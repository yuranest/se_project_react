import { createContext } from "react";
const CurrentTemperatureUnitContext = createContext();
export default CurrentTemperatureUnitContext;
