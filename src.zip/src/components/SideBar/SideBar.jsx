import React from "react";
import avatar from "../../assets/images/avatar.png";

const SideBar = () => {
  return (
    <aside className="sidebar">
      <img src={avatar} alt="User avatar" className="sidebar__avatar" />
      <p className="sidebar__username">Username</p>
    </aside>
  );
};

export default SideBar;
