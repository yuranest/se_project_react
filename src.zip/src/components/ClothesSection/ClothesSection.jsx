21;
import React from "react";
import ItemCard from "../ItemCard/ItemCard";

const ClothesSection = ({ clothingItems, onCardClick, onAddClick }) => {
  return (
    <section className="profile__clothes">
      <div className="profile__clothes-header">
        <p className="profile__subheading">Your items</p>
        <button className="profile__add-button" onClick={onAddClick}>
          + Add new
        </button>
      </div>
      <ul className="card__list">
        {clothingItems.map((item) => (
          <ItemCard key={item.id} item={item} onCardClick={onCardClick} />
        ))}
      </ul>
    </section>
  );
};

export default ClothesSection;
